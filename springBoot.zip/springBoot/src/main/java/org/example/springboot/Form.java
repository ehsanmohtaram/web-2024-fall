package org.example.springboot;

import jakarta.persistence.*;
import lombok.Data;
import lombok.ToString;

import java.util.ArrayList;
import java.util.List;


@Entity
@Data
public class Form {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id;

    private String name;
    private boolean publishedStatus;

    @OneToMany
    private List<Field> fields = new ArrayList<>();

    private String submitUrl;
}

