package org.example.springboot;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class MainController {
    private final MainService mainService;

    @GetMapping("/forms")
    public List<FormDto> getAllForms() {
        return mainService.getAllForms();
    }

    @PostMapping("/forms")
    public ResponseEntity<FormDto> creatForm(@RequestBody FormDto formDto) {
        return ResponseEntity.ok(mainService.createForm(formDto));
    }

    @GetMapping("/forms/{id}")
    public FormDto getForm(@PathVariable long id) {
        return mainService.getFormById(id);
    }

    @PutMapping("/forms/{id}")
    public ResponseEntity<FormDto> updateForm(@PathVariable Long id, @RequestBody FormDto formDto) {
        return ResponseEntity.ok(mainService.updateForm(id, formDto));
    }

    @DeleteMapping("forms/{id}")
    public void deleteForm(@PathVariable Long id) {
        mainService.deleteForm(id);
    }

    @GetMapping("forms/{id}/fields")
    public List<FieldDto> getFormFields(@PathVariable Long id) {
        return mainService.getFieldById(id);
    }

    @PutMapping("/forms/{id}/fields")
    public ResponseEntity<List<FieldDto>> updateField(@PathVariable Long id, @RequestBody List<FieldDto> fieldDtos) {
        List<FieldDto> updatedFields = mainService.updateField(id, fieldDtos);
        return ResponseEntity.ok(updatedFields);
    }

    @PostMapping("forms/{id}/publish")
    public void togglePublish(@PathVariable Long id) {
        mainService.togglePublish(id);
    }

    @GetMapping("forms/published")
    public List<FormDto> getPublishedForms() {
        return mainService.getPublishedForms();
    }

}
