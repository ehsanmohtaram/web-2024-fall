package org.example.springboot;

import jakarta.persistence.ElementCollection;
import lombok.Data;

import java.util.List;

@Data
public class FormDto {
    private int id;
    private String name;
    private boolean publishedStatus;
    private List<Field> fields;
    private String submitUrl;
}
