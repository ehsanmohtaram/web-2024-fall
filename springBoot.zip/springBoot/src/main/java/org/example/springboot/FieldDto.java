package org.example.springboot;
import lombok.Data;

@Data
public class FieldDto {
    private int id;
    private String name;
    private String label;
    private FieldType type;
    private String defaultValue;
}
