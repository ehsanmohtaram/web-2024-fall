package org.example.springboot;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class MainService {
    private final FormRepository formRepository;
    private final FieldRepository fieldRepository;


    private FormDto formtoFormDto(Form form) {
        FormDto formDto = new FormDto();
        formDto.setId(form.getId());
        formDto.setName(form.getName());
        formDto.setFields(form.getFields());
        formDto.setPublishedStatus(form.isPublishedStatus());
        formDto.setSubmitUrl(form.getSubmitUrl());
        return formDto;
    }

    private Form formDtoToForm(FormDto formDto) {
        Form form = new Form();
        form.setName(formDto.getName());
        form.setPublishedStatus(formDto.isPublishedStatus());
        form.setSubmitUrl(formDto.getSubmitUrl());

        List<Field> fields = formDto.getFields();
        for (Field field : fields) {
            fieldRepository.save(field);
        }
        form.setFields(fields);
        return form;
    }

    private FieldDto fieldToFieldDto(Field field) {
        FieldDto fieldDto = new FieldDto();
        fieldDto.setId(field.getId());
        fieldDto.setName(field.getName());
        fieldDto.setLabel(field.getLabel());
        fieldDto.setType(field.getType());
        fieldDto.setDefaultValue(field.getDefaultValue());
        return fieldDto;
    }

    private Field fieldDtoToField(FieldDto fieldDto) {
        Field field = new Field();
        field.setId(fieldDto.getId());
        field.setName(fieldDto.getName());
        field.setLabel(fieldDto.getLabel());
        field.setType(fieldDto.getType());
        field.setDefaultValue(fieldDto.getDefaultValue());
        return field;
    }

    public List<FormDto> getAllForms(){
       return formRepository.findAll().stream().map(form -> formtoFormDto(form)).collect(Collectors.toList());
    }

    public FormDto createForm(FormDto formDto) {
        Form form = formDtoToForm(formDto);
        return formtoFormDto(formRepository.save(form));
    }

    public FormDto getFormById(long id) {
        Form form = formRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Form by this id not found"));
        return formtoFormDto(form);
    }

    public FormDto updateForm(Long id, FormDto formDTO) {
        Form form = formRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Form by thi id not found"));
        form.setName(formDTO.getName());
        form.setPublishedStatus(formDTO.isPublishedStatus());
        form.setSubmitUrl(formDTO.getSubmitUrl());
        return formtoFormDto(formRepository.save(form));
    }

    public void deleteForm(Long id) {
        formRepository.deleteById(id);
    }

    public List<FieldDto> getFieldById(long id) {
        Form form = formRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Form by this id not found"));
        return form.getFields().stream().map(field -> fieldToFieldDto(field)).collect(Collectors.toList());
    }

    public List<FieldDto> updateField(long id, List<FieldDto> fieldDtos) {
        Form form = formRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Form by this id not found"));
        form.getFields().clear();

        List<Field> fields = fieldDtos.stream().map(fieldDto -> fieldDtoToField(fieldDto)).collect(Collectors.toList());
        for (Field field : fields) {
            fieldRepository.save(field);
        }
        form.setFields(fields);
        return formRepository.save(form).getFields().stream().map(field -> fieldToFieldDto(field)).collect(Collectors.toList());
    }

    public void togglePublish(Long id) {
        Form form = formRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Form bt this id not found"));
        System.out.printf("ali");
        form.setPublishedStatus(!form.isPublishedStatus());
        formRepository.save(form);
    }

    public List<FormDto> getPublishedForms() {
        return formRepository.findByPublishedStatus(true).stream().map(form -> formtoFormDto(form)).collect(Collectors.toList());
    }



}
