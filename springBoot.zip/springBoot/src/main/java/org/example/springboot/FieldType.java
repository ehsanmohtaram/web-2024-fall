package org.example.springboot;

public enum FieldType {
    TEXT,
    NUMBER,
    BOOLEAN,
    DATE
}
